
Applying hclasp to Labyrinth, Sokoban, Hanoi Towers
---------------------------------------------------

Files and folders:
 <problem>/heuristics: heuristic files used with hclasp for the problem
 <problem>/instances: instances for the problem
 <problem>/encoding: encoding for the problem
 
USAGE:

heuristic files with _flu and tetris modify the fluents, without flu the actions.

heuristics<_flu>.lp are used via constant substitution for the global modifier and value:
  gringo <problem encoding> <problem instance> heuristics<_flu>.lp  -c mod=<modifier> -c n=<value> | \
    clasp --heu=domain
    
orderedHeuristics<Inverse><_flu>.lp are used via constant substitution for modifier only 
and the values are calculated via the timestamp of the action/fluent (without inverse - ascending; with inverse - descending):
  gringo <problem encoding> <problem instance> orderedHeuristics<Inverse><_flu>.lp  -c mod=<modifier> | \
    clasp --heu=domain
    
tetris<-fluent>.lp needs neither modifier nor value:
  gringo <problem encoding> <problem instance> tetris<-fluent>.lp | \
    clasp --heu=domain

For more information on modifiers and values visit the hclasp help section.