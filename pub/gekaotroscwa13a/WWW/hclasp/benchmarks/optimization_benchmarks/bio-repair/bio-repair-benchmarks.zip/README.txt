

Applying hclasp to Biological Network Repair
--------------------------------------------


Files and folders:
 heuristics: heuristic files used with hclasp
 repair-and-prediction.tar.gz: encoding and instances from http://www.cs.uni-potsdam.de/bioasp/KR10
 results: results of the experiments of the paper (experiments for level=1 are in files *-level1.ods)
 
We recommend to read the README in repair-and-prediction.tar.gz for information on the basic usage of gringo and clasp
 for the experiments.
 
 
USAGE:

To compute a cardinality minimal repair for experimental data heatShock_WT_26_03.lp with repair operations 'eiv',
 using sign=-1 for the abducibles, type:

  gringo -c mode=sign -c value=-1 -c repair=eiv input.gringo repair_config.gringo repair_core.gringo repair_cardinality.gringo tf_sig_bnum.lp \ 
    obs/heatShock_WT/03/heatShock_WT_26_03.lp heuristic-template-1.lp | hclasp --heu=domain

For other hclasp configurations, just give other values to constants mode and value (f.e., "-c mode=factor -c value=2").

To combine two heuristic modifiers, use file heuristic-template-2.lp and give the corresponding values to constants mode, value, mode2 and value2.
For example, to use sign=1 and factor=2 for abducibles, type:

  gringo -c mode=sign -c value=-1 -c mode2=factor -c value2=2 -c repair=eiv input.gringo repair_config.gringo repair_core.gringo repair_cardinality.gringo tf_sig_bnum.lp \ 
    obs/heatShock_WT/03/heatShock_WT_26_03.lp heuristic-template-1.lp | hclasp --heu=domain
