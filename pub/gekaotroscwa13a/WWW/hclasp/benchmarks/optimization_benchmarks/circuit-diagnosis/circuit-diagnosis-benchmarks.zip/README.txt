
Applying hclasp to Circuit Diagnosis
------------------------------------

Files and folders:
 heuristics: heuristic files used with hclasp
 iscas85.zip: encoding and instances for ISCAS85 circuit diagnosis
 results: results of the experiments of the paper
 
We recommend to read the README in iscas85.zip for information on the basic usage of gringo and clasp
 for the experiments.
 
 
USAGE:

For minimum cardinality diagnosis in circuit c432 with 4 output gates changed on instance 1, 
 using sign=-1 for abducibles, type:  

  gringo -c mode=sign -c value=-1 heuristic-template-1.lp diagnosis.lp gates.lp minimize.lp lp/c432.lp instances/c432.lp.1.in instances/c432.lp.1.4.out | \
    hclasp --heu=domain 
	
For other hclasp configurations, just give other values to constants mode and value (f.e., "-c mode=factor -c value=2").

To combine two heuristic modifiers, use file heuristic-template-2.lp and give the corresponding values to constants mode, value, mode2 and value2.
For example, to use sign=1 and factor=2 for abducibles, type:
  gringo -c mode=sign -c value=-1 -c mode2=factor -c value2=2 heuristic-template-1.lp diagnosis.lp gates.lp minimize.lp lp/c432.lp instances/c432.lp.1.in instances/c432.lp.1.4.out | \
    hclasp --heu=domain 
 
